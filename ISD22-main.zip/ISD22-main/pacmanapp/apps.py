from django.apps import AppConfig


class PacmanappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "pacmanapp"
